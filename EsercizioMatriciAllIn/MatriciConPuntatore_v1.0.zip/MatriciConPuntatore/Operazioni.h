void MatriceMoltiplicazione(float *matrice, float *matrice2, float *matrice3);
void MatriceTrasposta(float *matrice, float *matrice3);
void MatriceSomma(float *matrice, float *matrice2, float *matrice3);
void ProdottoScalare(float *matrice, float *matrice3);
