void MatriceTrasposta(float matrice[], float matrice3[]);
