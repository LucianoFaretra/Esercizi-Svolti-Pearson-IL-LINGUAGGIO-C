void MatriceSomma(float matrice[], float matrice2[], float matrice3[]);
