void InserimentoNumeroRighe(float matrice[], int n);
void InserimentoNumeroColonne(float matrice[]);
void ControlloMatrice(float matrice[], int n);
