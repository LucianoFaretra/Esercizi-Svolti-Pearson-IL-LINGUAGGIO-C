void ProdottoScalare(float matrice[], float matrice3[]);
