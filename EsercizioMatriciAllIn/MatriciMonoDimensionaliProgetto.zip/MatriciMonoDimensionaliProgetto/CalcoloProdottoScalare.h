void CalcoloProdottoScalare(float matrice[], float matrice3[], float scalare);
