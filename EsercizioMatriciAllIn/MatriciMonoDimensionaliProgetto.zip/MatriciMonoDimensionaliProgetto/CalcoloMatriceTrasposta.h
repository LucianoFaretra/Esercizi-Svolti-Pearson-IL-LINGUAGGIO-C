void CalcoloMatriceTrasposta(float matrice[], float matrice3[]);
