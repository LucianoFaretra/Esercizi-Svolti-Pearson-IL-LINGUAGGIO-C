void ControlloVincoloProdottoDueMatrici(float matrice[], float matrice2[], float matrice3[]);
