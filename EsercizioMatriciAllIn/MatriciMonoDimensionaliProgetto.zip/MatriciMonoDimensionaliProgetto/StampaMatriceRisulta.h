void StampaMatriceRisulta(float matrice[]);
